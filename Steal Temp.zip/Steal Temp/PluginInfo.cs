﻿namespace StupidTemplate
{
    internal class PluginInfo
    {
        public const string GUID = "org.tmp.gorillatag.pasting";
        public const string Name = "Not Steal";
        public const string Description = "Created by @cum_gobbler99 with love <3 (in a gay way)";
        public const string Version = "1.0.0";
    }
}
