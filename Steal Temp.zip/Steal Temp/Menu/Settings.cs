﻿using StupidTemplate.Classes;
using UnityEngine;
using static StupidTemplate.Menu.Main;

namespace StupidTemplate
{
    internal class Settings
    {
        public static ExtGradient backgroundColor = new ExtGradient{isRainbow = false};
        public static ExtGradient[] buttonColors = new ExtGradient[]
        {
            new ExtGradient{colors = GetSolidGradient(new Color(0.2f, 0.2f, 0.2f))}, // Disabled
            new ExtGradient{colors = GetSolidGradient(new Color(0.3f, 0.3f, 0.3f))} // Enabled
        };
        public static Color[] textColors = new Color[]
        {
            Color.white, // Disabled
            Color.green // Enabled
        };

        public static Font currentFont = (Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font);

        public static bool fpsCounter = false;
        public static bool disconnectButton = true;
        public static bool rightHanded = false;
        public static bool disableNotifications = true;

        public static KeyCode keyboardButton = KeyCode.Q;

        public static Vector3 menuSize = new Vector3(0.1f, 1f, 1.1f); // Depth, Width, Height
        public static int buttonsPerPage = 6;
        internal static int pageshit;
        public static Vector3 pageprev = new Vector3(0.56f, 0.225f, -0.475f);
        public static Vector3 pagenext = new Vector3(0.56f, -0.225f, -0.475f);

        public static Vector3 scale = new Vector3(0.09f, 0.35f, 0.0925f);

        public static Vector3 textprev = new Vector3(0.064f, 0.07f, -0.18f);
        public static Vector3 textnext = new Vector3(0.064f, -0.07f, -0.18f);



        public static void Themes()
        {
            string[] themes = { "Purple", "Light", "Blue", "Pink", "Dark" };

            if (themes.Length == 0) return;

            Settings.pageshit++;
            if (Settings.pageshit > themes.Length)
            {
                Settings.pageshit = 1;
            }

            switch (Settings.pageshit)
            {
                case 1:
                    backgroundColor = new ExtGradient { colors = GetSolidGradient(new Color32(111, 14, 181, 255)) };
                    buttonColors = new ExtGradient[]
                    {
                    new ExtGradient { colors = GetSolidGradient(new Color32(99, 41, 143, 255))},
                    new ExtGradient { colors = GetSolidGradient(new Color32(145, 68, 201, 255))}
                    };
                    textColors = new Color[] { Color.white, Color.white };
                    break;

                case 2:
                    backgroundColor = new ExtGradient { colors = GetSolidGradient(new Color(0.7f, 0.7f, 0.7f)) };
                    buttonColors = new ExtGradient[]
                    {
                    new ExtGradient { colors = GetSolidGradient(new Color(0.8f, 0.8f, 0.8f))},
                    new ExtGradient { colors = GetSolidGradient(new Color(0.9f, 0.9f, 0.9f))}
                    };
                    textColors = new Color[] { Color.white, Color.white };
                    break;

                case 3:
                    backgroundColor = new ExtGradient { colors = GetSolidGradient(new Color32(59, 59, 59, 255)) };
                    buttonColors = new ExtGradient[]
                    {
                    new ExtGradient { colors = GetSolidGradient(new Color(0.2f, 0.2f, 0.6f))},
                    new ExtGradient { colors = GetSolidGradient(new Color32(49, 0, 196, 255))}
                    };
                    textColors = new Color[] { Color.white, Color.white };
                    break;

                case 4:
                    backgroundColor = new ExtGradient { colors = GetSolidGradient(new Color(0.8f, 0.6f, 0.8f)) };
                    buttonColors = new ExtGradient[]
                    {
                    new ExtGradient { colors = GetSolidGradient(new Color(1f, 0.6f, 0.8f))},
                    new ExtGradient { colors = GetSolidGradient(new Color(1f, 0.8f, 0.6f))}
                    };
                    textColors = new Color[] { Color.white, Color.white };
                    break;

                case 5:
                    backgroundColor = new ExtGradient { colors = GetSolidGradient(new Color(0.1f, 0.1f, 0.1f))};
                    buttonColors = new ExtGradient[]
                    {
                    new ExtGradient { colors = GetSolidGradient(new Color(0.2f,0.2f,0.2f))},
                    new ExtGradient { colors = GetSolidGradient(new Color(0.3f,0.3f,0.3f))}
                    };
                    textColors = new Color[] { Color.white, Color.white };
                    break;
            }
        }


        public static void Button()
        {
            string[] themes = { "Side", "Bottom"};

            if (themes.Length == 0) return;

            Settings.pageshit++;
            if (Settings.pageshit > themes.Length)
            {
                Settings.pageshit = 1;
            }

            switch (Settings.pageshit)
            {
                case 1:
                    pageprev = new Vector3(0.56f, 0.65f, 0);
                    pagenext = new Vector3(0.56f, -0.65f, 0);

                    scale = new Vector3(0.09f, 0.125f, 0.66f);

                    textprev = new Vector3(0.064f, 0.195f, 0);
                    textnext = new Vector3(0.064f, -0.195f, 0);
                    break;

                case 2:
                    pageprev = new Vector3(0.56f, 0.225f, -0.475f);
                    pagenext = new Vector3(0.56f, -0.225f, -0.475f);

                    scale = new Vector3(0.09f, 0.35f, 0.0925f);

                    textprev = new Vector3(0.064f, 0.07f, -0.18f);
                    textnext = new Vector3(0.064f, -0.07f, -0.18f);
                    break;
            }
        }
    }
}
