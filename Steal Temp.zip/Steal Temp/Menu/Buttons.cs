﻿using GorillaNetworking;
using Photon.Pun;
using StupidTemplate.Classes;
using StupidTemplate.Mods;
using UnityEngine;
using static StupidTemplate.Settings;

namespace StupidTemplate.Menu
{
    internal class Buttons
    {
        public static ButtonInfo[][] buttons = new ButtonInfo[][]
        {
            new ButtonInfo[] {

                new ButtonInfo { buttonText = "Room", method =() => Main.buttonsType = 1, isTogglable = false},
                new ButtonInfo { buttonText = "Movement", method =() => Main.buttonsType = 2, isTogglable = false},
                new ButtonInfo { buttonText = "Player", method =() => Main.buttonsType = 3, isTogglable = false},
                new ButtonInfo { buttonText = "Visual", method =() => Main.buttonsType = 4, isTogglable = false},
                new ButtonInfo { buttonText = "Overpowered", method =() => Main.buttonsType = 5, isTogglable = false},
                new ButtonInfo { buttonText = "Settings", method =() => Main.buttonsType = 6, isTogglable = false},
            },

            new ButtonInfo[] {
                new ButtonInfo { buttonText = "Disconnect", method =() => PhotonNetwork.Disconnect(), isTogglable = false},
                new ButtonInfo { buttonText = "Join Random", method = () => PhotonNetworkController.Instance.AttemptToJoinPublicRoom(GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Forest, Tree Exit").GetComponent<GorillaNetworkJoinTrigger>(), 0), isTogglable = false },
                new ButtonInfo { buttonText = "USW Servers", method = () => PhotonNetwork.ConnectToRegion("usw"), isTogglable = false },
                new ButtonInfo { buttonText = "EU Servers", method = () => PhotonNetwork.ConnectToRegion("eu"), isTogglable = false },
            },

            new ButtonInfo[] {

            },

            new ButtonInfo[] {

            },

            new ButtonInfo[] {

            },

            new ButtonInfo[] {

            },

            new ButtonInfo[] {
                new ButtonInfo { buttonText = "Right Hand", enableMethod =() => SettingsMods.RightHand(), disableMethod =() => SettingsMods.LeftHand(), toolTip = "Puts the menu on your right hand."},
                new ButtonInfo { buttonText = "Change Theme", method =() => Settings.Themes(), isTogglable = false},
                new ButtonInfo { buttonText = "Change Button Type", method =()=> Settings.Button(), isTogglable = false},

            },

            new ButtonInfo[] { // ignore
                new ButtonInfo { buttonText = "卐卐卐 Nigga Heil Hitler 卍卍卍", method =() => Global.ReturnHome(), isTogglable = false},
            },
        };
    }
}
